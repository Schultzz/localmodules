/**
 * Created by MS on 22-03-2015.
 */
var http = require('http');
var request = require("request"),
    cheerio = require('cheerio');

var sLink = 'http://www.eurovision.tv/page/history/by-year/contest?event=1893&utm_expid=2244945-1._AXiGacbSfGmfXcW7aC8vw.0&utm_referrer=http%3A%2F%2Fwww.eurovision.tv%2Fpage%2Fcopenhagen-2014%2Fabout';
var cache;
var tableData = [];

module.exports = {

    getQoute: function getQuote(callback){
    var url = "http://www.iheartquotes.com/api/v1/random";
    http.get(url, function(response){
        response.setEncoding("utf8");
        response.on("data",function(data){
            callback(data);
        });

    });
},
    get: function get(id){
        var options = {
            url: "http://web-schultz.rhcloud.com/api/person/complete/"+id,
            method: 'GET',
            json: true
        };

        request(options, function (error, response, body) {
            if (!error && response.statusCode === 200) {
                return console.log(JSON.stringify(body));
            }
            console.log(error + " : " + JSON.stringify(body));
        });
    },
    cacheIt: function(){
        console.log("caching");
        request(sLink, function (err, res,  body) {
            if (!err && res.statusCode == 200) {
                cache = body;
                console.log('Done!');
                var $ = cheerio.load(body);
                $('tr.nowinner', '#participants-default-1893').each(function () {
                    var artistName = $(this).find('span').text();
                    var songName = $(this).find(':nth-child(4)').text().split('\n')[1];
                    var country = $(this).find('a.sortValue').text();
                    var points = $(this).find('td.points').html();
                    var place = $(this).find('td.place').html();
                    var pos = $(this).find('td.ro').html();
                    var obj = {'artist':artistName, 'songName':songName, 'pos': pos ,'country':country, 'points':points, 'place': place};

                    tableData.push(obj);

                });
            }
        });

    },
    getCountry: function (cId, callback){
        var searchHit = tableData.filter(function(elem){
            return cId === elem.country;
        });

        callback(JSON.stringify(searchHit));
    }

}


